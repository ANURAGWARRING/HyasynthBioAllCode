# VernierLib
Library to make reading Vernier sensors used on a Vernier Interface Shield easy.
